
for(let a=1000; a<1100; a++){
    if (a%3==2 && a%5==3 && a%7==2){
        console.log(a);
    }
}